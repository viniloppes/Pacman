﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman.CLASSES
{
    public static class DadosGerais
    {
        public static int toutMovePacman = 0;
        public const int TOUT_MOVE_PACMAN = 100;



    }
}
